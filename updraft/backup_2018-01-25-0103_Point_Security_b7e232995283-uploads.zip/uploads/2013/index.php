<?php

/**
 * WordPress Content Copy Protection Premium is brought to you by YOOPlugins.com
 */

?>
<br /><br />
<center>Sorry, you are not authorized to access this area ! Goodbye !</center><br />
<center>Protect your online content with <a href="http://yooplugins.com/downloads/wp-content-copy-protection-pro/">WP Content Copy Protection Pro</a> - The No.1 WordPress Copy Protection Plugin on the Web</center><br />