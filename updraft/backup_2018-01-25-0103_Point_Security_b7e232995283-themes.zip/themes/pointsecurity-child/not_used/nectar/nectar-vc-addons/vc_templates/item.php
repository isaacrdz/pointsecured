<?php 

echo '<li class="col span_4">' . do_shortcode($content) . '</li>';

?>